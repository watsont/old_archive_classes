// stdafx.cpp : source file that includes just the standard includes
// Lab 4.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


