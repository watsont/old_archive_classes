// Program Dinner prints out a dinner menu              // 1

const SALAD = "Green Salad";                            // 2
const MEAT = "Chicken Marsala";                         // 3
const VEGGIE = 'Carrots with lemon butter';             // 4
STARCH = "Mashed potatoes"                              // 5

int main                                                // 6
{
    string mainCourse;                                  // 7
     
    cout  << "First course: "  << SALAD  << endl;       // 8
    mainCourse = MEAT + "with" + VEGGIE + "and          // 9
        + STARCH;                                       // 10
    cout  << "Main course: "  << mainCourse  << endl;   // 11
    cout  << "Dessert: "  << DESSERT;                   // 12
}                                                       // 13

