// Program Dinner prints out a dinner menu
#include <iostream>
#include <string>
using namespace std;

const SALAD = "Green Salad";
const MEAT = "Chicken Marsala";
const VEGGIE = "Carrots with lemon butter";
const STARCH = "Mashed potatoes";
const DESSERT = "Apple pie";

int main ()
{
    string mainCourse;

    cout  << "First course: "  << SALAD  << endl;
    mainCourse = MEAT + "with" + VEGGIE + "and" 
        + STARCH;
    cout  << "Main course: "  << mainCourse  << endl;
    cout  << "Dessert: "  << DESSERT;
    return 0;
}

