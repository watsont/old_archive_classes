// Program Shell
#include <iostream>
#include <string>
using namespace std;

const string FIRST_NAME ="Joel";
const string LAST_NAME = "Garcia";
const string BLANK = " ";
const string COMMA = ",";
const string TODAY = "05/12/08";

int main ()
{
	string message;

	message = LAST_NAME + COMMA + BLANK + FIRST_NAME;
	cout << message;




	return 0;
}