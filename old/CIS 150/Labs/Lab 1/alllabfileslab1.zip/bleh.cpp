// Program Shell
#include <iostream>
#include <string>
using namespace std;

const string FIRST_NAME ="Joel";
const string LAST_NAME = "Garcia";
const string BLANK = " ";
const string COMMA = ",";
const string TODAY = "05/12/2008";

int main ()
{
	string message;

	message = FIRST_NAME + BLANK + LAST_NAME;
	cout << message << endl;




	return 0;
}