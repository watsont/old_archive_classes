// Program Shell1 is for investigating the differences between
// automatic and static variables.

#include <iostream>
using namespace std;

void  TestLocals();

int main ()
{
    TestLocals ();
    TestLocals ();
    TestLocals ();
    return 0;
}

// ***************************************

void  TestLocals()
{
    /* TO BE FILLED IN */
}

